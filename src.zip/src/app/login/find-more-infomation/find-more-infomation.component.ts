import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-more-infomation',
  templateUrl: './find-more-infomation.component.html',
  styleUrls: ['./find-more-infomation.component.css']
})
export class FindMoreInfomationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

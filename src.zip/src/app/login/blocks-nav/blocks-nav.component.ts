import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocks-nav',
  templateUrl: './blocks-nav.component.html',
  styleUrls: ['./blocks-nav.component.css']
})
export class BlocksNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export class UserLogin{
    phone:string;
    password:string;
}
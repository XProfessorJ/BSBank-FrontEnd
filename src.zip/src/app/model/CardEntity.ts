export class CardEntity{
     cardId:string;
     productName:string;
     profuctCode:string;
     accountNickname:string;
     displayAccountNumber:string;
     currencyCode:string;
     accountClassification:string;
     accountStatus:string;
     currentBalance:number;
     availableBalance:number;
     accountId:string;
}
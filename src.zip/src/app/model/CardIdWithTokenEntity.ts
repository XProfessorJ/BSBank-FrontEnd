export class CardIdWithTokenEntity{
    cardId:string;
    token:string;
    pagenum:number;
    pagerow:number;
}
export class AccountWithTokenEntity{
    accountId:string;
    token:string;
}
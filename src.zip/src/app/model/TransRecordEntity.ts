export class TransRecordEntity{
    cardId:string;
    ppositeCardId:string;
    Timestamp:string;
    inOrOut:string;
    amount:number;
    balancenumber;
    summarynumber;
    postscript:string;
    settlementDate:string;
}
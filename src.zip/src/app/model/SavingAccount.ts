import { CardEntity } from "./CardEntity";

export class SavingCard extends CardEntity{
}
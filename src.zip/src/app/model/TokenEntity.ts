export class TokenEntity{
    token:string;
}
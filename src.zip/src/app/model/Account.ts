export class Account{
    accountId:string;
    accountType:string;
    accountStatus:string;
}
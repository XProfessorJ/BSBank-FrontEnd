export class CustomerEntity{
     customerId:string
     customerType:string
     names:string
     gender:string
     prefix:string
     suffix:string
     customerSegment:string
     partnerCustomerSegment:string
     phone:string
     email:string
     password:string
}